// Configure the custom colors and fonts used by the Tailwind utility classes.
window.tailwind = {
  config: {
    theme: {
      extend: {
        colors: {
          ink: "#211b35",
          violet: "#7655e8",
          lilac: "#f2edff"
        },
        fontFamily: {
          sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"]
        }
      }
    }
  }
};

// Wait until the HTML is ready before connecting the page interactions.
document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.querySelector("#menu-toggle");
  const mobileMenu = document.querySelector("#mobile-menu");
  const openIcon = menuButton.querySelector(".menu-open");
  const closeIcon = menuButton.querySelector(".menu-close");

  function setMenuOpen(isOpen) {
    mobileMenu.dataset.open = String(isOpen);
    mobileMenu.classList.toggle("hidden", !isOpen);
    menuButton.setAttribute("aria-expanded", String(isOpen));
    menuButton.setAttribute(
      "aria-label",
      isOpen ? "Close navigation menu" : "Open navigation menu"
    );
    openIcon.classList.toggle("hidden", isOpen);
    closeIcon.classList.toggle("hidden", !isOpen);
  }

  menuButton.addEventListener("click", () => {
    setMenuOpen(mobileMenu.dataset.open !== "true");
  });

  // Close the menu after a visitor selects a section.
  mobileMenu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => setMenuOpen(false));
  });

  // Keep the footer year current automatically.
  document.querySelector("#year").textContent = new Date().getFullYear();
});
